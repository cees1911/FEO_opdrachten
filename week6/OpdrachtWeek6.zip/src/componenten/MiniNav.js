import React from "react"
import {Link} from "react-router-dom"

const styleLi = {
    listStyle: "none",
    textAlign: "center",
    display: "inline",
    fontSize: 15
    }   
    
const styleUl = {
    width: "60%",
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    listStyle: "none"    }
    
const styleNav={
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    background: "#4A90E2",
    color: "#fff",
    marginTop: 0,
    padding: 0 , 
    width: "250px",
    borderRadius: "100px"
    }

    function MiniNav(){

        return(
            <nav style={styleNav}>
            Kies:            
            <ul style={styleUl}>
                <li style={styleLi}><Link to = "/BarGrafiek">Beide</Link></li>
                <li style={styleLi}>  |  </li>
                <li style={styleLi}><Link to = "/BarGrafiek/LeukBar">Leuk</Link></li>
                <li style={styleLi}>  |  </li>
                <li style={styleLi}><Link to = "/BarGrafiek/MoeilijkBar">Moeilijk</Link></li>
            </ul>
        </nav>        
        )

    }
export default MiniNav