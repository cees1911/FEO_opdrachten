import React from "react";
import avarageData from "./DataAverage";
import { 
        VictoryLine, 
        VictoryChart, 
        VictoryAxis,         
        VictoryTheme,
        VictoryLegend        
    } from 'victory';



class LijnGrafiek extends React.Component {

    render() {
        return(
        <VictoryChart 
                height={250}
                width={600}
                domainPadding = {30} theme={VictoryTheme.material}>
            <VictoryLegend x={220} y={30}  	            
                orientation="horizontal"                
                data={[             
                { name: "moeilijk", symbol: { fill: "#F4511E" },  },
                { name: "leuk", symbol: { fill: "#4A90E2" } }                            
                    ]} />      
           <VictoryLine
                style={{        
                    data: { stroke: "#4A90E2" },
                    parent: { border: "1px solid #ccc" }}}        
                data={avarageData}        
                x="opdracht"       
                y="leuk"/>
            <VictoryLine
                style={{        
                    data: { stroke: "#F4511E" },
                    parent: { border: "1px solid #ccc" }}}        
                data={avarageData}        
                x="opdracht"       
                y="moeilijk"/>      
            <VictoryAxis  
                    style={{ tickLabels:  { angle: -80, fontSize: 6  } }}       
                   tickValues={[1, 2, 3, 4, 5]}
                   tickFormat={avarageData.map((label)=> label.opdracht )}/>  
            <VictoryAxis dependentAxis />
        </VictoryChart>
        )
    }
}



export default LijnGrafiek