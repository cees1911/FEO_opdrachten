import React from "react";
import {Link} from "react-router-dom"


const styleNav={
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    background: "#c5c7c9",
    color: "#fff",
    marginTop: 0,
    padding: 0 , 
    
}

const styleUl={
    width: "30%",
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    listStyle: "none"    
}

const styleLink={
    color: "#fff"
}

function Navigatie(){
    return(
        <nav style={styleNav}>
            <ul style={styleUl}>
                <Link style={styleLink} to="/BarGrafiek">
                    <li>Bar grafiek</li>
                </Link>
                <Link style={styleLink} to="/LijnGrafiek">
                    <li>Lijn grafiek</li>
                </Link>
                <Link style={styleLink} to="/Studenten">
                    <li>Studenten</li>
                </Link>
            </ul>
        </nav>
    )
}    

export default Navigatie