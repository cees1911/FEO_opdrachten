import React from "react"

const style= { 
        padding: 5,       
        backgroundColor:"#4A90E2", 
        color:"#fff",
        fontSize: 9,
        textAlign: "right",
        minHeight: "2vh",
        borderRadius: "80px"
}

function Footer(){
    return(
        <p style={style}>copyright: Spaghetti Brein  2020</p>
    )
}

export default Footer