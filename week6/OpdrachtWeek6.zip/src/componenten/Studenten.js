import React from "react"
import {Link} from "react-router-dom"


const styleH1= {
        textAlign: "center"
        }

const styleLi = {
        listStyle: "none",
        textAlign: "center"
}

const styleP = {
        textAlign: "center",
        fontSize: 20
}




function Studenten(){       
             
    return(
        <div>
            <h1 style={styleH1} >Studenten</h1>
            <p style={styleP}> Selecteer een student om de individuele scores te zien</p>
            <ul>
                <li style={styleLi}><h2><Link to = "/Studenten/Aranka">Aranka</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Evelyn">Evelyn</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Floris">Floris</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Hector">Hector</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Martina">Martina</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Maurits">Maurits</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Rahima">Rahima</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Sandra">Sandra</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Storm">Storm</Link></h2></li>
                <li style={styleLi}><h2><Link to = "/Studenten/Wietske">Wietske</Link></h2></li>       
                
            </ul>
        </div>
    )
}


export default Studenten

//
//