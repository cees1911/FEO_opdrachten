import React from "react"

const style= {
            backgroundColor:"#4A90E2", 
            color:"#fff",
            marginTop: 0,
            marginBottom: 0,
            padding: 0,
            textAlign: "center",
            minHeight: "7vh",
            textAlignVertical: "center",
           
            }

function Header(){
    return(
        <h1 style={style}>Studenten Dashboard</h1>
    )
}

export default Header
