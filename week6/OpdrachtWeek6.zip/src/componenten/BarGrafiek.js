import React from 'react';
import avarageData from "./DataAverage"
import MiniNav from "./MiniNav"
import { VictoryBar, 
         VictoryChart, 
         VictoryAxis,         
         VictoryTheme,
         VictoryLegend, 
         VictoryGroup
       } from 'victory';


         

class BarGrafiek extends React.Component {  
  
    render() {
      return (
        <div>
          <br/>            
        <br/>
        <MiniNav />
          <br/>
          <br/>
          <br/>
          <VictoryChart 
              height={250}
              width={600}
              domainPadding = {30} theme={VictoryTheme.material}>
            <VictoryLegend x={220} y={20}  	            
                orientation="horizontal"                
                data={[             
                { name: "moeilijk", symbol: { fill: "#F4511E" },  },
                { name: "leuk", symbol: { fill: "#4A90E2" } }                            
                    ]} />
            <VictoryGroup offset={5}>
              < VictoryBar 
                  style={{ data: { fill: "#F4511E" }} }
                  data={avarageData}        
                  x="opdracht"                  
                  y="moeilijk" />
              <VictoryBar
                  style={{ data: { fill: "#4A90E2" } }}              
                  data={avarageData}        
                  x="opdracht"                  
                  y="leuk" />                  
            </VictoryGroup>
            <VictoryAxis 
                    style={{ tickLabels:  { angle: -80, fontSize: 6 } }} 
                   tickValues={[1, 2, 3, 4, 5]}
                   tickFormat={avarageData.map((label)=> label.opdracht )}/>  
            <VictoryAxis dependentAxis />        
          </VictoryChart> 
        </div>
      );
    }
  }

  export default BarGrafiek