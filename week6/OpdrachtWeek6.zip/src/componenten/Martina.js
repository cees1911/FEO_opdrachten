import React from "react";
import MartinaData from "./MartinaData";
import {
  VictoryBar,
  VictoryChart,
  VictoryAxis,
  VictoryTheme,
  VictoryLegend,
  VictoryGroup,
} from "victory";

function Martina() {
  const styleH1 = { 
    textAlign: "center",
    color: "#4B90E2" };

  return (
    <div>
      <h1 style={styleH1}>Martina</h1>
      <VictoryChart
        height={250}
        width={600}
        domainPadding={30}
        theme={VictoryTheme.material}>
        <VictoryLegend x={220} y={20}  	            
          orientation="horizontal"                
          data={[             
            { name: "moeilijk", symbol: { fill: "#F4511E" },  },
            { name: "leuk", symbol: { fill: "#4A90E2" } }                            
          ]} />
        <VictoryGroup offset={5}>
          <VictoryBar
            style={{ data: { fill: "#F4511E" } }}
            data={MartinaData}
            x="opdracht"
            y="moeilijk"
          />
          <VictoryBar
            style={{ data: { fill: "#4A90E2" } }}
            data={MartinaData}
            x="opdracht"
            y="leuk"
          />
        </VictoryGroup>
        <VictoryAxis
          style={{ tickLabels: { angle: -80, fontSize: 6 } }}
          tickValues={[1, 2, 3, 4, 5]}
          tickFormat={MartinaData.map((label) => label.opdracht)}
        />
        <VictoryAxis dependentAxis />
      </VictoryChart>
    </div>
  );
}

export default Martina;
