import React from "react";
import avarageData from "./DataAverage"
import MiniNav from "./MiniNav"

import { VictoryBar, 
         VictoryChart, 
         VictoryAxis,         
         VictoryTheme,
        } from 'victory';

const styleH2= {
        textAlign: "center",
        color: "#F4511E"
            }

        

function MoeilijkBar(){
    return(
        <div>
            <br/>            
            <br/>
            <MiniNav /> 
            <h2 style={styleH2}> Moeilijk</h2>          
            <VictoryChart 
              height={250}
              width={600}
              domainPadding = {30} theme={VictoryTheme.material}>
          < VictoryBar 
              style={{ data: { fill: "#F4511E" }} }
              data={avarageData}        
              x="opdracht"                  
              y="moeilijk" />
              <VictoryAxis 
                    style={{ tickLabels:  { angle: -80, fontSize: 6 } }} 
                   tickValues={[1, 2, 3, 4, 5]}
                   tickFormat={avarageData.map((label)=> label.opdracht )} />  
            <VictoryAxis dependentAxis />        
          </VictoryChart>

        </div>
    )
}

export default MoeilijkBar