import React from "react";
import BarGrafiek from "./componenten/BarGrafiek"
import LijnGrafiek from "./componenten/LijnGrafiek"
import Leuk from "./componenten/LeukBar"
import Moeilijk from "./componenten/MoeilijkBar"
import Studenten from "./componenten/Studenten"
import Navigatie from "./componenten/Navigatie"
import Header from "./componenten/Header"
import Footer from "./componenten/Footer"
import Aranka from "./componenten/Aranka"
import Evelyn from "./componenten/Evelyn"
import Floris from "./componenten/Floris"
import Hector from "./componenten/Hector"
import Martina from "./componenten/Martina"
import Maurits from "./componenten/Maurits"
import Rahima from "./componenten/Rahima"
import Sandra from "./componenten/Sandra"
import Storm from "./componenten/Storm"
import Muts from "./componenten/Wietske"

import {BrowserRouter as Router,
        Switch,
        Route} from "react-router-dom"




function App() {
  return (
    <Router>
      <div> 
        <Header /> 
        <Navigatie /> 
        <Switch>     
          <Route path = "/BarGrafiek" exact component={BarGrafiek} /> 
          <Route path = "/BarGrafiek/LeukBar" component={Leuk} /> 
          <Route path = "/BarGrafiek/MoeilijkBar" component={Moeilijk} /> 
          <Route path = "/LijnGrafiek" component={LijnGrafiek} />
          <Route path = "/Studenten" exact component={Studenten} />
          <Route path = "/studenten/Aranka" component={Aranka} />
          <Route path = "/studenten/Evelyn" component={Evelyn} />
          <Route path = "/studenten/Floris" component={Floris} />
          <Route path = "/studenten/Hector" component={Hector} />
          <Route path = "/studenten/Martina" component={Martina} />
          <Route path = "/studenten/Maurits" component={Maurits} />
          <Route path = "/studenten/Rahima" component={Rahima} />
          <Route path = "/studenten/Sandra" component={Sandra} />
          <Route path = "/studenten/Storm" component={Storm} />
          <Route path = "/studenten/Wietske" component={Muts} />
        </Switch>
        <Footer />
      </div>
    </Router>
  )
}

export default App;
